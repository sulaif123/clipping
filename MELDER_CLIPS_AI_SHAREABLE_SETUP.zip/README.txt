# MELDER CLIPS AI - Windows package

## First-time setup (each new PC)
1. Extract this ZIP into a normal folder, for example `C:\MELDER-CLIPS-AI`.
2. Install **Python 3.11 (64-bit)** if it is not already installed:
   https://www.python.org/downloads/release/python-3119/
   During installation, tick **Add python.exe to PATH**.
3. Install FFmpeg and add its `bin` directory to Windows PATH.
4. Double-click `setup.bat`. It creates a local `venv` and installs packages from `requirements.txt`.
5. When setup completes, double-click `start.bat`.

## Normal use
- Start: `start.bat`
- Stop: `stop.bat`
- Open: http://localhost:5173

## Important
- Do not share your personal `venv`, generated videos, clips, logs, or database unless you intend to.
- This ZIP contains the application source and setup scripts, not a bundled copy of Python or FFmpeg.
- Internet is required for first-time pip installation and downloading AI models/videos.
- GPU acceleration depends on the recipient's NVIDIA GPU, drivers, CUDA/CTranslate2 compatibility, and FFmpeg encoders. CPU fallback is available where supported.
