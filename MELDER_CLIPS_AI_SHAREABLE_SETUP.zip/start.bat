@echo off
setlocal
cd /d "%~dp0"
title MELDER CLIPS AI

if not exist "venv\Scripts\python.exe" (
  echo Python environment is not installed yet.
  echo Please run setup.bat first.
  pause
  exit /b 1
)

if not exist "backend\main.py" (
  echo ERROR: backend\main.py is missing.
  pause
  exit /b 1
)
if not exist "backend\engine.py" (
  echo ERROR: backend\engine.py is missing.
  pause
  exit /b 1
)
if not exist "backend\gpu.py" (
  echo ERROR: backend\gpu.py is missing.
  pause
  exit /b 1
)

start "" /min cmd /c "ping -n 5 127.0.0.1 >nul & start http://localhost:5173"
echo Starting MELDER CLIPS AI...
echo Keep this window open while the app is running.
echo Press Ctrl+C here or run stop.bat to stop it.
venv\Scripts\python.exe run_server.py

echo.
echo MELDER CLIPS AI stopped.
pause
endlocal
