@echo off
echo Stopping MELDER CLIPS AI on port 5173...
for /f "tokens=5" %%p in ('netstat -ano ^| findstr ":5173" ^| findstr "LISTENING"') do taskkill /PID %%p /T /F >nul 2>&1
echo Stopped.
pause
