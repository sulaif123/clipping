"""Windows-safe launcher for MELDER CLIPS AI."""
import asyncio
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)

if os.name == "nt":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

import uvicorn

if (ROOT / "backend" / "main.py").is_file():
    app_import = "backend.main:app"
else:
    app_import = "main:app"

if __name__ == "__main__":
    uvicorn.run(
        app_import,
        host="127.0.0.1",
        port=5173,
        log_level="info",
        access_log=False,
        ws="websockets",
    )
