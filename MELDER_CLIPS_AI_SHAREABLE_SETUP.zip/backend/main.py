import asyncio, json, os, shutil, site, sqlite3, subprocess, threading, time, traceback, uuid
from pathlib import Path

# Windows: choose Selector before Uvicorn creates the event loop.
# This avoids noisy Proactor pipe-transport reset callbacks when clients disconnect.
if os.name == "nt":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

if hasattr(os, "add_dll_directory"):  # Windows: let CTranslate2 find the pip-installed CUDA DLLs
    for sp in site.getsitepackages():
        for b in Path(sp).glob("nvidia/*/bin"):
            os.add_dll_directory(str(b))
            os.environ["PATH"] = str(b) + os.pathsep + os.environ["PATH"]

from fastapi import FastAPI, File, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
try:
    from . import engine, gpu  # normal layout: backend/ folder
except ImportError:
    import engine, gpu  # flat layout: all files in one folder

import logging


class _QuietResets(logging.Filter):
    """Windows prints harmless 'connection forcibly closed' noise when the browser drops a video stream."""
    def filter(self, record):
        return not (record.exc_info and isinstance(record.exc_info[1], (ConnectionResetError, ConnectionAbortedError)))


logging.getLogger("asyncio").addFilter(_QuietResets())

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent if HERE.name == "backend" else HERE
DIRS = {d: ROOT / d for d in ["projects", "videos", "clips", "exports", "models", "cache", "logs"]}
for d in DIRS.values():
    d.mkdir(exist_ok=True)
DB = DIRS["projects"] / "melder.db"
CANCEL, PROCS = set(), {}


class Cancelled(Exception):
    pass


def q(sql, args=(), one=False):
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    try:
        rows = c.execute(sql, args).fetchall()
        c.commit()
    finally:
        c.close()
    return (rows[0] if rows else None) if one else rows


q("CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY, params TEXT, status TEXT, progress REAL, message TEXT, result TEXT, created REAL)")
q("UPDATE jobs SET status='failed', message='Interrupted by a restart. Press Retry.' WHERE status='running'")  # crash recovery


def upd(jid, **kw):
    q(f"UPDATE jobs SET {','.join(k + '=?' for k in kw)} WHERE id=?", (*kw.values(), jid))


def view(jid):
    r = q("SELECT * FROM jobs WHERE id=?", (jid,), True)
    if not r:
        return {"id": jid, "status": "failed", "message": "Unknown job", "progress": 0, "result": []}
    d = dict(r)
    d["params"], d["result"] = json.loads(d["params"]), json.loads(d["result"] or "[]")
    return d


def chk(jid):
    if jid in CANCEL:
        raise Cancelled()


def choose_model(cfg, p, fast=False):
    if p.get("model"):
        return p["model"]
    if p.get("language") == "ml":
        return "small"  # tiny/base are poor at Malayalam
    if cfg["device"] == "cpu":
        return "small" if fast else "base"
    return "small" if cfg["vram"] <= 5000 else "medium"


def load_model(jid, cfg, size):
    from faster_whisper import WhisperModel
    upd(jid, message=f"Loading Whisper '{size}' on {cfg['device'].upper()}…")
    return WhisperModel(size, device=cfg["device"], compute_type=cfg["compute"],
                        cpu_threads=os.cpu_count() or 4, download_root=str(DIRS["models"]))


def tx(jid, holder, cfg, size, st, audio, offset=0.0, on_seg=None):
    """Transcribe one audio/video file. Speed settings: greedy decoding, no context carry-over, all CPU threads."""
    kw = dict(word_timestamps=True, vad_filter=True, vad_parameters={"min_silence_duration_ms": 500},
              beam_size=1, best_of=1, temperature=(0.0, 0.4), compression_ratio_threshold=2.2,
              log_prob_threshold=-1.0, no_speech_threshold=0.6, repetition_penalty=1.1,
              condition_on_previous_text=False)
    for attempt in (0, 1):
        try:
            it, info = holder[0].transcribe(str(audio), language=st["lang"], **kw)
            segs, words = [], []
            for s in it:
                chk(jid)
                segs.append({"start": s.start + offset, "end": s.end + offset, "text": s.text.strip()})
                words += [{"start": w.start + offset, "end": w.end + offset, "word": w.word.strip()}
                          for w in (s.words or []) if w.word.strip()]
                if on_seg:
                    on_seg(s)
            if segs and not st["lang"]:
                st["lang"] = info.language
            return segs, words
        except Cancelled:
            raise
        except Exception as e:
            if cfg["device"] == "cuda" and attempt == 0:
                cfg.update(device="cpu", compute="int8", note=f"GPU AI failed, switched to CPU: {str(e)[:90]}")
                holder[0] = load_model(jid, cfg, size)
                continue
            raise


def transcribe(jid, video, cfg, p, dur):
    size = choose_model(cfg, p)
    holder = [load_model(jid, cfg, size)]
    st = {"lang": p.get("language") or None}

    def on_seg(s):
        upd(jid, progress=10 + 35 * min(1, s.end / dur),
            message=f"Transcribing everything on {cfg['device'].upper()} ({size}): {int(s.end)}s / {int(dur)}s")
    return tx(jid, holder, cfg, size, st, video, 0.0, on_seg)


def analyze_fast(jid, video, cfg, p, dur, n):
    """Fast scan: pick the most promising stretches by audio energy, then transcribe ONLY those."""
    target = int(p.get("duration", 45))
    upd(jid, progress=8, message="Fast scan: listening for exciting moments…")
    wins = engine.audio_windows(video, target, max(n * 2, 6))
    size = choose_model(cfg, p, True)
    holder = [load_model(jid, cfg, size)]
    st = {"lang": p.get("language") or None}
    segs, words = [], []
    for k, (ws, we) in enumerate(wins):
        chk(jid)
        wav = DIRS["cache"] / f"{jid}_{k}.wav"
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{ws:.2f}", "-i", str(video), "-t", f"{we - ws:.2f}",
                        "-vn", "-ac", "1", "-ar", "16000", str(wav)], check=True)
        s, w = tx(jid, holder, cfg, size, st, wav, ws)
        wav.unlink(missing_ok=True)
        segs += s
        words += w
        upd(jid, progress=12 + 33 * (k + 1) / len(wins),
            message=f"Fast scan: transcribing moment {k + 1}/{len(wins)} on {cfg['device'].upper()} ({size})")
    return segs, words


def pipeline(jid):
    p = json.loads(q("SELECT params FROM jobs WHERE id=?", (jid,), True)["params"])
    try:
        cfg = gpu.resolve(p.get("mode", "auto"), gpu.detect())
        upd(jid, status="running", progress=1, message=f"AI device: {cfg['device'].upper()} | encoder: {cfg['encoder']} {cfg['note']}")
        src = p["source"].strip()
        if src.startswith("http"):
            upd(jid, message="Downloading video (needs internet)…")
            d = DIRS["videos"] / jid
            d.mkdir(exist_ok=True)
            import yt_dlp
            try:
                with yt_dlp.YoutubeDL({"format": "bv*[height<=1080]+ba/b[height<=1080]/b", "merge_output_format": "mp4",
                                       "outtmpl": str(d / "source.%(ext)s"), "noplaylist": True, "quiet": True}) as y:
                    y.download([src])
                video = next(d.glob("source.*"))
            except Exception as ex:
                raise RuntimeError("Could not download this link (check internet, or download the video yourself and use the file option): " + str(ex)[:150])
        else:
            video = Path(src.strip('"'))
            if not video.exists():
                raise RuntimeError("File not found: " + str(video))
        chk(jid)
        try:
            dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0",
                                        str(video)], capture_output=True, text=True).stdout.strip())
        except ValueError:
            raise RuntimeError("This file is not a readable video.")
        n = int(p.get("count") or 5)
        if p.get("analysis", "fast") == "fast" and dur > 360:
            segs, words = analyze_fast(jid, video, cfg, p, dur, n)
        else:
            segs, words = transcribe(jid, video, cfg, p, dur)
        segs, words = engine.clean_transcript(segs, words)
        if not segs:
            raise RuntimeError("No speech detected in this video.")
        upd(jid, progress=47, message="Finding the best moments…")
        clips = engine.candidates(segs, int(p.get("duration", 45)), n)
        if not clips:
            raise RuntimeError("No clip-worthy segments found. Try a different clip length.")
        for c in clips:
            chk(jid)
            meta = engine.template_meta(c["text"])
            if p.get("llm"):
                try:
                    meta.update({k: v for k, v in engine.ollama_meta(p["llm"], c["text"], p.get("caption_lang", "English")).items() if v})
                except Exception:
                    meta["caption"] += "\n(Ollama unavailable: template caption used)"
            c.update(meta)
            c["score"] = int(c.get("score") or 50)
        clips.sort(key=lambda c: -c["score"])
        out_dir = DIRS["clips"] / jid
        out_dir.mkdir(exist_ok=True)
        done, t0 = [], time.time()
        for i, c in enumerate(clips, 1):
            def prog(f, fps, i=i):
                el = time.time() - t0
                frac = (i - 1 + f) / len(clips)
                eta = int(el / frac - el) if frac > 0.02 else 0
                upd(jid, progress=55 + 45 * frac,
                    message=f"Rendering {i}/{len(clips)} with {cfg['encoder']}: {fps:.0f} fps | elapsed {int(el)}s | ~{eta}s left")
            f = engine.render(video, c, words, out_dir, i, cfg["encoder"], p, lambda pr: PROCS.__setitem__(jid, pr), prog,
                              stop=lambda: jid in CANCEL)
            chk(jid)
            if c.get("enc") and c["enc"] != cfg["encoder"]:
                cfg.update(encoder=c["enc"], note="GPU encoder failed, switched to CPU encoder")
            done.append({**{k: c[k] for k in ("title", "hook", "caption", "hashtags", "keywords", "score", "start", "end")},
                         "file": f"{jid}/{f.name}"})
            upd(jid, result=json.dumps(done))
        upd(jid, status="done", progress=100, message=f"Done: {len(done)} clips ({cfg['device'].upper()} AI, {cfg['encoder']})")
    except Cancelled:
        upd(jid, status="cancelled", message="Cancelled")
    except Exception as e:
        (DIRS["logs"] / f"{jid}.log").write_text(traceback.format_exc())
        upd(jid, status="failed", message=str(e)[:300])
    finally:
        CANCEL.discard(jid)
        PROCS.pop(jid, None)


def start(jid):
    threading.Thread(target=pipeline, args=(jid,), daemon=True).start()


app = FastAPI(title="MELDER CLIPS AI")


@app.on_event("startup")
async def install_asyncio_disconnect_handler():
    """Ignore expected Windows socket-reset cleanup errors, but report other errors."""
    loop = asyncio.get_running_loop()
    previous_handler = loop.get_exception_handler()

    def handle_loop_exception(loop, context):
        exc = context.get("exception")
        if isinstance(exc, (ConnectionResetError, ConnectionAbortedError)):
            return
        if previous_handler is not None:
            previous_handler(loop, context)
        else:
            loop.default_exception_handler(context)

    loop.set_exception_handler(handle_loop_exception)


app.mount("/clips", StaticFiles(directory=DIRS["clips"]), name="clips")


@app.get("/")
def index():
    f = ROOT / "frontend" / "index.html"
    return FileResponse(f if f.exists() else ROOT / "index.html", headers={"Cache-Control": "no-store"})


@app.get("/api/gpu")
def api_gpu():
    return {**gpu.detect(), **gpu.usage()}


@app.post("/api/upload")
async def upload(f: UploadFile = File(...)):
    dest = DIRS["videos"] / f"{uuid.uuid4().hex[:8]}_{Path(f.filename).name}"
    with open(dest, "wb") as o:
        shutil.copyfileobj(f.file, o)
    return {"path": str(dest)}


@app.post("/api/jobs")
def create(p: dict):
    jid = uuid.uuid4().hex[:10]
    q("INSERT INTO jobs VALUES(?,?,?,?,?,?,?)", (jid, json.dumps(p), "queued", 0, "Queued", "[]", time.time()))
    start(jid)
    return {"id": jid}


@app.get("/api/jobs")
def jobs():
    return [view(r["id"]) for r in q("SELECT id FROM jobs ORDER BY created DESC LIMIT 30")]


@app.get("/api/jobs/{jid}")
def job(jid: str):
    return view(jid)


@app.post("/api/jobs/{jid}/cancel")
def cancel(jid: str):
    CANCEL.add(jid)
    pr = PROCS.get(jid)
    if pr:
        pr.kill()
    return {"ok": True}


@app.post("/api/jobs/{jid}/retry")
def retry(jid: str):
    upd(jid, status="queued", progress=0, message="Retrying…", result="[]")
    start(jid)
    return {"ok": True}


@app.delete("/api/jobs/{jid}")
def delete(jid: str):
    shutil.rmtree(DIRS["clips"] / jid, ignore_errors=True)
    shutil.rmtree(DIRS["videos"] / jid, ignore_errors=True)
    q("DELETE FROM jobs WHERE id=?", (jid,))
    return {"ok": True}


@app.post("/api/cache/clean")
def clean_cache():
    shutil.rmtree(DIRS["cache"], ignore_errors=True)
    DIRS["cache"].mkdir(exist_ok=True)
    return {"ok": True}


@app.websocket("/ws/{jid}")
async def ws(w: WebSocket, jid: str):
    await w.accept()
    try:
        while True:
            v = view(jid)
            await w.send_json(v)
            if v["status"] in ("done", "failed", "cancelled"):
                break
            await asyncio.sleep(0.5)
    except (WebSocketDisconnect, ConnectionResetError, ConnectionAbortedError):
        # The browser may close the tab or refresh while updates are being sent.
        pass
    except OSError as exc:
        # Treat socket-level disconnects as normal client departures.
        if getattr(exc, "winerror", None) not in (10053, 10054, 10058):
            raise
