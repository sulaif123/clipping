@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title MELDER CLIPS AI - Setup

echo ==============================================
echo          MELDER CLIPS AI - FIRST SETUP
echo ==============================================
echo.

where py >nul 2>&1
if not errorlevel 1 (
    py -3.11 --version >nul 2>&1
    if not errorlevel 1 (
        set "PYTHON_CMD=py -3.11"
        goto create_env
    )
)

where python >nul 2>&1
if not errorlevel 1 (
    python -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,11) else 1)" >nul 2>&1
    if not errorlevel 1 (
        set "PYTHON_CMD=python"
        goto create_env
    )
)

echo ERROR: Python 3.11 was not found.
echo.
echo Install Python 3.11 (64-bit) from:
echo https://www.python.org/downloads/release/python-3119/
echo During installation, enable "Add python.exe to PATH".
echo Then close this window and run setup.bat again.
echo.
pause
exit /b 1

:create_env
if exist "venv\Scripts\python.exe" (
    echo Existing virtual environment found.
) else (
    echo Creating private Python environment...
    %PYTHON_CMD% -m venv venv
    if errorlevel 1 goto failed
)

echo.
echo Updating pip...
venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto failed

echo.
echo Installing MELDER CLIPS AI dependencies...
venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failed

echo.
echo Checking FFmpeg...
where ffmpeg >nul 2>&1
if errorlevel 1 (
    echo WARNING: FFmpeg was not found.
    echo Install FFmpeg and add its bin folder to Windows PATH.
    echo Video download, probing, and rendering need FFmpeg.
) else (
    echo FFmpeg found.
)

echo.
echo ==============================================
echo SETUP COMPLETED.
echo Now double-click start.bat to run MELDER CLIPS AI.
echo ==============================================
pause
exit /b 0

:failed
echo.
echo SETUP FAILED. Check the error messages above.
echo Check your internet connection and Python 3.11 installation.
pause
exit /b 1
