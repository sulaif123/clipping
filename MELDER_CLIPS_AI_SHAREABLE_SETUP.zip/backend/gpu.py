"""Hardware detection and safe acceleration selection for MELDER CLIPS AI.

GPU acceleration is optional. Whisper uses CUDA only when CTranslate2 reports a
usable CUDA device. FFmpeg NVENC is selected only when the encoder is listed;
engine.py retries with libx264 if the actual encode fails.
"""
from __future__ import annotations

import os
import shutil
import subprocess
from typing import Any


def _run(args: list[str], timeout: int = 5) -> str:
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return (p.stdout or "").strip()
    except (OSError, subprocess.SubprocessError):
        return ""


def _ffmpeg_encoders() -> str:
    if not shutil.which("ffmpeg"):
        return ""
    return _run(["ffmpeg", "-hide_banner", "-encoders"], timeout=8)


def detect() -> dict[str, Any]:
    ffmpeg = bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))
    encoders = _ffmpeg_encoders()
    nvenc = "h264_nvenc" in encoders

    gpu_name = None
    vram_mb = 0
    util_pct = None
    smi = shutil.which("nvidia-smi")
    if smi:
        out = _run([smi, "--query-gpu=name,memory.total,utilization.gpu",
                    "--format=csv,noheader,nounits"], timeout=5)
        if out:
            fields = [x.strip() for x in out.splitlines()[0].split(",")]
            if fields:
                gpu_name = fields[0] or None
            if len(fields) > 1:
                try:
                    vram_mb = int(float(fields[1]))
                except ValueError:
                    pass
            if len(fields) > 2:
                try:
                    util_pct = float(fields[2])
                except ValueError:
                    pass

    cuda_ai = False
    cuda_compute = []
    try:
        import ctranslate2
        count = int(ctranslate2.get_cuda_device_count())
        cuda_ai = count > 0
        if cuda_ai:
            try:
                cuda_compute = sorted(ctranslate2.get_supported_compute_types("cuda", 0))
            except Exception:
                cuda_compute = []
    except Exception:
        pass

    # Don't claim a GPU exists if neither NVIDIA tooling nor CUDA AI can see one.
    if not gpu_name and cuda_ai:
        gpu_name = "NVIDIA CUDA device"

    return {
        "gpu": gpu_name,
        "vram_mb": vram_mb,
        "cuda_ai": cuda_ai,
        "nvenc": nvenc,
        "ffmpeg": ffmpeg,
        "util_pct": util_pct,
        "cuda_compute": cuda_compute,
    }


def usage() -> dict[str, Any]:
    info = detect()
    return {"util_pct": info.get("util_pct")}


def resolve(mode: str, info: dict[str, Any] | None = None) -> dict[str, Any]:
    info = info or detect()
    mode = (mode or "auto").lower()
    if mode not in ("auto", "gpu", "cpu"):
        mode = "auto"

    # The GT 740 and other older cards may expose NVENC without supporting
    # the CUDA/cuDNN stack required by the installed CTranslate2 build.
    use_cuda = mode != "cpu" and bool(info.get("cuda_ai"))
    if mode == "gpu" and not use_cuda:
        note = "CUDA Whisper unavailable; using CPU safely."
    elif use_cuda:
        note = "CUDA Whisper available."
    else:
        note = "CPU Whisper mode."

    supported = info.get("cuda_compute") or []
    compute = "float16" if "float16" in supported else (
        "int8_float16" if "int8_float16" in supported else "int8"
    )
    if not use_cuda:
        compute = "int8"

    encoder = "h264_nvenc" if mode != "cpu" and info.get("nvenc") else "libx264"
    return {
        "device": "cuda" if use_cuda else "cpu",
        "compute": compute,
        "encoder": encoder,
        "vram": int(info.get("vram_mb") or 0),
        "note": note,
    }
