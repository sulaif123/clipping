import json, re, subprocess, urllib.request
from pathlib import Path

RATIOS = {"9:16": (1080, 1920), "16:9": (1920, 1080), "1:1": (1080, 1080), "4:5": (1080, 1350)}
HOOK = re.compile(r"\b(secret|never|always|mistake|why|how|stop|biggest|worst|best|truth|nobody|everyone|"
                  r"crazy|insane|money|free|warning|actually|finally|problem|win|lose|love|hate)\b", re.I)
ML = re.compile(r"[\u0D00-\u0D7F]")
# name: (highlight, base, size, outline, karaoke, words per line)
STYLES = {"hormozi": ("&H0000E6FF", "&H00FFFFFF", 88, 7, True, 3),
          "karaoke": ("&H00FFC800", "&H00FFFFFF", 80, 6, True, 4),
          "word": ("&H0000E6FF", "&H00FFFFFF", 120, 8, False, 1),
          "minimal": ("&H00FFFFFF", "&H00FFFFFF", 62, 3, False, 5)}


STOP = set("""the a an and or but if so to of in on at for with as is are was were be been being it its this that these those
i you he she we they me my your our their his her them him us do does did have has had not no yes just very really like um uh
yeah okay oh well then there here what which who when where why how from by about into over than too also can could would
should will get got going thing things know think people want one all some any more most much many even still only other
such because actually never always tells said says again really maybe something someone""".split())
FILLER = re.compile(r"^\W*(so|and|um|uh|yeah|okay|ok|well|like|but|then|right|oh|i mean)\b", re.I)
WORD = re.compile(r"[\w\u0D00-\u0D7F]+")


def sentences(text):
    out, seen = [], set()
    for s in re.split(r"(?<=[.?!।])\s+", text.strip()):
        k = re.sub(r"\W+", " ", s.lower()).strip()
        if k and k not in seen:
            seen.add(k)
            out.append(s.strip())
    return out


def sent_score(t):
    n = len(t.split())
    sc = -3.0 if n < 4 else (1.5 if 6 <= n <= 18 else 0.0)
    sc += 2.0 * min(2, len(HOOK.findall(t)))
    sc += 2.0 if "?" in t else 0
    sc += 1.0 if "!" in t else 0
    sc += 0.8 * min(2, len(re.findall(r"\d+", t)))
    sc += 1.2 if re.search(r"\b(you|your)\b", t, re.I) else 0
    sc += 1.0 if re.search(r"\b(but|however|actually|instead|except|until|never)\b", t, re.I) else 0
    sc -= 2.0 if FILLER.match(t) else 0
    return sc


def clean_transcript(segs, words):
    """Remove Whisper repetition loops and duplicate lines, and the words that belong to them."""
    import zlib
    keep, prev = [], ""
    for s in segs:
        t = re.sub(r"\b(.{4,}?)(?:[\s,.]+\1\b){2,}", r"\1", s["text"], flags=re.I)
        k = re.sub(r"\W+", " ", t.lower()).strip()
        raw = t.encode("utf-8")
        if not k or k == prev or (prev and k in prev) or (len(raw) > 40 and len(raw) / len(zlib.compress(raw)) > 2.4):
            continue
        prev = k
        keep.append({**s, "text": t})
    rng = [(s["start"], s["end"]) for s in keep]
    return keep, [w for w in words if any(a - 0.05 <= w["start"] and w["end"] <= b + 0.05 for a, b in rng)]


def candidates(segs, target, n):
    """Local highlight scoring: strong opening sentence, rich non-repetitive content, complete thought."""
    out = []
    for i, s in enumerate(segs):
        j = i
        while (j + 1 < len(segs) and segs[j + 1]["end"] - s["start"] <= target
               and segs[j + 1]["start"] - segs[j]["end"] <= 6):
            j += 1
        dur = segs[j]["end"] - s["start"]
        if dur < max(8, target * 0.5) or dur > target * 1.1:
            continue
        part = segs[i:j + 1]
        text = " ".join(x["text"] for x in part)
        toks = WORD.findall(text.lower())
        uniq = len(set(toks)) / max(1, len(toks))
        ss = [sent_score(x["text"]) for x in part]
        content = {w for w in toks if w not in STOP and len(w) > 3}
        sc = 2.5 * ss[0] + sum(ss) / len(ss) + 6 * uniq + min(3.0, len(content) / dur * 1.5)
        if uniq < 0.45:
            sc -= 8
        if text.rstrip()[-1:] in ".?!।":
            sc += 1
        out.append({"start": s["start"], "end": segs[j]["end"], "text": text, "score": sc})
    out.sort(key=lambda c: -c["score"])
    chosen = []
    for c in out:
        if all(c["end"] + 10 <= x["start"] or c["start"] >= x["end"] + 10 for x in chosen):
            chosen.append(c)
        if len(chosen) == n:
            break
    lo = min([c["score"] for c in chosen] or [0])
    hi = max([c["score"] for c in chosen] or [1])
    for c in chosen:
        c["score"] = int(55 + 45 * (c["score"] - lo) / (hi - lo)) if hi > lo else 80
    return chosen


def audio_windows(video, target, k, pad=4):
    """Fast scan: find the k loudest, most dynamic stretches (likely exciting speech) without transcribing."""
    import numpy as np
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", str(video), "-vn", "-ac", "1", "-ar", "8000",
                          "-f", "s16le", "-"], capture_output=True).stdout
    a = np.frombuffer(raw, dtype=np.int16).astype(np.float32)
    secs = len(a) // 8000
    L = int(target)
    if secs <= L + 2 * pad:
        return [(0.0, float(secs))]
    rms = np.sqrt((a[:secs * 8000].reshape(secs, 8000) ** 2).mean(axis=1))
    c1 = np.concatenate([[0], np.cumsum(rms)])
    c2 = np.concatenate([[0], np.cumsum(rms ** 2)])
    starts = np.arange(0, secs - L + 1, 3)
    mean = (c1[starts + L] - c1[starts]) / L
    std = np.sqrt(np.maximum((c2[starts + L] - c2[starts]) / L - mean ** 2, 0))
    g = rms.mean() + 1e-6
    sc = mean / g * 0.6 + std / g * 0.4
    sc[mean < 0.35 * g] = -1  # mostly silence
    chosen = []
    for i in np.argsort(-sc):
        if sc[i] <= 0 or len(chosen) >= k:
            break
        ws, we = max(0.0, float(starts[i]) - pad), min(float(secs), float(starts[i]) + L + pad)
        if all(we <= x or ws >= y for x, y in chosen):
            chosen.append((ws, we))
    return sorted(chosen) or [(0.0, float(min(secs, L + 2 * pad)))]


def template_meta(text):
    ss = sentences(text) or [text]
    cut = lambda s, k: " ".join(s.split()[:k]).rstrip(",;:")
    best, hook = max(ss, key=sent_score), max(ss[:2], key=sent_score)
    freq = {}
    for w in WORD.findall(text.lower()):
        if len(w) > 4 and w not in STOP and not w.isdigit():
            freq[w] = freq.get(w, 0) + 1
    tags = ["#" + w for w, _ in sorted(freq.items(), key=lambda x: (-x[1], -len(x[0])))[:4]] + ["#shorts", "#reels"]
    body = " ".join(ss[:2])[:150].rsplit(" ", 1)[0]
    return {"title": cut(best, 12)[:60], "hook": cut(hook, 9),
            "caption": body + "…\n\nFollow for more! " + " ".join(tags), "hashtags": tags,
            "keywords": [t[1:] for t in tags]}


def ollama_meta(model, text, lang):
    prompt = (f"Write viral short-video metadata in {lang} for this clip transcript. Use only facts from it. "
              'Return JSON: {"title":str,"hook":str(max 8 words),"caption":str(with call to action),'
              '"hashtags":[str],"keywords":[str],"score":1-100}\n\nTRANSCRIPT:\n' + text[:3000])
    req = urllib.request.Request("http://127.0.0.1:11434/api/generate", headers={"Content-Type": "application/json"},
                                 data=json.dumps({"model": model, "prompt": prompt, "stream": False, "format": "json"}).encode())
    return json.loads(json.load(urllib.request.urlopen(req, timeout=180))["response"])


def face_track(video, start, end, step=0.5):
    """Sample the clip twice a second: find faces, pick the one whose mouth area moves most (the speaker)."""
    try:
        import cv2
    except ImportError:
        return None
    if not hasattr(cv2, "CascadeClassifier"):  # OpenCV 5 dropped it: install opencv-python-headless<5
        return None
    cap = cv2.VideoCapture(str(video))
    fw = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
    if not fw:
        return None
    sc = min(1.0, 640.0 / fw)
    det = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    prof = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_profileface.xml")

    def prep(f):
        g = cv2.cvtColor(f, cv2.COLOR_BGR2GRAY)
        return cv2.resize(g, None, fx=sc, fy=sc) if sc < 1 else g
    track, t = [], start
    while t < end:
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
        ok, f1 = cap.read()
        if not ok:
            break
        ok2, f2 = True, None
        for _ in range(3):
            ok2, f2 = cap.read()
        g1 = prep(f1)
        g2 = prep(f2) if ok2 and f2 is not None else g1
        m = (max(20, int(g1.shape[1] * 0.03)),) * 2
        faces = list(det.detectMultiScale(g1, 1.1, 5, minSize=m)) or list(prof.detectMultiScale(g1, 1.1, 5, minSize=m))
        best, bs = None, -1.0
        for (x, y, w, h) in faces:
            a = g1[y + h // 2:y + h, x:x + w].astype("int16")
            b = g2[y + h // 2:y + h, x:x + w].astype("int16")
            s = (float(abs(a - b).mean()) if a.shape == b.shape and a.size else 0.0) + 0.02 * w
            if s > bs:
                bs, best = s, (x + w / 2) / g1.shape[1]
        track.append((t - start, best))
        t += step
    cap.release()
    return track


def crop_keys(track, dur):
    """Turn raw speaker positions into a smooth plan: hold on a speaker, glide quickly when it changes."""
    if not track:
        return None
    xs, last = [], None
    for _, x in track:
        last = x if x is not None else last
        xs.append(last)
    first = next((x for x in xs if x is not None), None)
    if first is None:
        return None
    xs = [first if x is None else x for x in xs]
    sm = []
    for i in range(len(xs)):
        w = sorted(xs[max(0, i - 2):i + 3])
        sm.append(w[len(w) // 2])
    keys, cur = [(0.0, sm[0])], sm[0]
    for (t, _), x in zip(track, sm):
        if abs(x - cur) > 0.09:
            keys += [(max(keys[-1][0], t - 0.4), cur), (t, x)]
            cur = x
    keys.append((max(dur, keys[-1][0] + 0.1), cur))
    if len(keys) > 60:
        avg = sum(sm) / len(sm)
        return [(0.0, avg), (dur, avg)]
    return keys


def lerp_expr(keys):
    e = f"{keys[-1][1]:.4f}"
    for (t0, x0), (t1, x1) in reversed(list(zip(keys, keys[1:]))):
        if t1 <= t0:
            continue
        seg = f"{x0:.4f}" if abs(x1 - x0) < 1e-6 else f"({x0:.4f}+({x1 - x0:.4f})*(t-{t0:.2f})/{t1 - t0:.2f})"
        e = f"if(lt(t,{t1:.2f}),{seg},{e})"
    return e


def ts(t):
    h, r = divmod(max(t, 0), 3600)
    m, s = divmod(r, 60)
    return f"{int(h)}:{int(m):02d}:{s:05.2f}"


def clean(s):
    return re.sub(r"[{}\\\n]", "", s)


def make_ass(words, start, end, hook, style, path, W, H):
    hi, base, size, outl, kara, per = STYLES.get(style, STYLES["hormozi"])
    ws = [w for w in words if w["start"] >= start - 0.05 and w["end"] <= end + 0.3]
    alltxt = hook + " " + " ".join(w["word"] for w in ws)
    font = "Nirmala UI" if ML.search(alltxt) else "Arial"  # Windows system font with Malayalam glyphs
    sc = H / 1920
    head = (f"[Script Info]\nScriptType: v4.00+\nPlayResX: {W}\nPlayResY: {H}\n\n[V4+ Styles]\n"
            "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,"
            "Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding\n"
            f"Style: Default,{font},{int(size*sc*1.0)},{hi},{base},&H00000000,&H64000000,1,0,0,0,100,100,0,0,1,{outl},2,2,60,60,{int(520*sc)},1\n"
            f"Style: Hook,{font},{int(78*sc)},&H00FFFFFF,&H00FFFFFF,&H00000000,&H64000000,1,0,0,0,100,100,0,0,1,8,3,8,70,70,{int(260*sc)},1\n\n"
            "[Events]\nFormat: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text\n")
    ev = []
    if hook:
        ev.append(f"Dialogue: 1,{ts(0)},{ts(3.2)},Hook,,0,0,0,,{{\\fad(150,200)}}{clean(hook).upper()}")
    for i in range(0, len(ws), per):
        ch = ws[i:i + per]
        parts = []
        for j, w in enumerate(ch):
            nxt = ch[j + 1]["start"] if j + 1 < len(ch) else w["end"]
            k = "{\\k%d}" % max(1, round((nxt - w["start"]) * 100)) if kara else ""
            parts.append(k + clean(w["word"]).upper())
        ev.append(f"Dialogue: 0,{ts(ch[0]['start']-start)},{ts(ch[-1]['end']-start)},Default,,0,0,0,,{' '.join(parts)}")
    Path(path).write_text(head + "\n".join(ev), encoding="utf-8")


def _render(video, clip, words, out_dir, idx, enc, o, on_proc, on_prog):
    W, H = RATIOS.get(o.get("ratio", "9:16"), RATIOS["9:16"])
    if o.get("res") == "720":
        W, H = int(W * 2 / 3) // 2 * 2, int(H * 2 / 3) // 2 * 2
    ass = f"clip{idx}.ass"
    make_ass(words, clip["start"], clip["end"], clip.get("hook", ""), o.get("style", "hormozi"), out_dir / ass, W, H)
    keys = None
    if o.get("track", True) and o.get("ratio", "9:16") != "16:9":
        try:
            keys = crop_keys(face_track(video, clip["start"], clip["end"]), clip["end"] - clip["start"])
        except Exception:
            keys = None
    xexp = f"max(0,min(iw-ow,({lerp_expr(keys)})*iw-ow/2))" if keys else "(iw-ow)/2"
    vf = (f"crop=w='min(iw,ih*{W}/{H})':h='min(ih,iw*{H}/{W})':x='{xexp}':y='(ih-oh)/2',"
          f"scale={W}:{H},setsar=1,subtitles={ass}")
    pre = o.get("preset", "balanced")
    if enc == "h264_nvenc":
        v = ["-c:v", "h264_nvenc", "-preset", {"fast": "p2", "balanced": "p4", "high": "p6"}[pre], "-rc", "vbr",
             "-cq", {"fast": "24", "balanced": "21", "high": "18"}[pre], "-b:v", "0"]
    else:
        v = ["-c:v", "libx264", "-preset", {"fast": "superfast", "balanced": "veryfast", "high": "medium"}[pre],
             "-crf", {"fast": "24", "balanced": "21", "high": "18"}[pre]]
    out = out_dir / f"short_{idx:02d}.mp4"
    dur = clip["end"] - clip["start"]
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-progress", "pipe:1", "-nostats", "-ss", f"{clip['start']:.2f}",
           "-i", str(Path(video).resolve()), "-t", f"{dur:.2f}", "-vf", vf, "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
           *v, "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", out.name]
    p = subprocess.Popen(cmd, cwd=out_dir, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    on_proc(p)
    tail, fps = [], 0.0
    for line in p.stdout:
        line = line.strip()
        if line.startswith("out_time_us="):
            try:
                on_prog(min(1.0, int(line.split("=")[1]) / 1e6 / dur), fps)
            except ValueError:
                pass
        elif line.startswith("fps="):
            try:
                fps = float(line.split("=")[1])
            except ValueError:
                pass
        elif "=" not in line:
            tail.append(line)
    if p.wait() != 0:
        raise RuntimeError("ffmpeg failed: " + " ".join(tail[-5:]))
    return out


def render(video, clip, words, out_dir, idx, enc, o, on_proc, on_prog, stop=None):
    """Render with the chosen encoder; if the GPU encoder fails, retry on CPU automatically."""
    try:
        out = _render(video, clip, words, out_dir, idx, enc, o, on_proc, on_prog)
        clip["enc"] = enc
        return out
    except RuntimeError:
        if enc == "libx264" or (stop and stop()):
            raise
        out = _render(video, clip, words, out_dir, idx, "libx264", o, on_proc, on_prog)
        clip["enc"] = "libx264"
        return out
